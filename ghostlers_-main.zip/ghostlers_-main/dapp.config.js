const config = {
  title: 'Ghostlers',
  description: 'The Last test version of Ghostlers Contract',
    contractAddress: '0xc168abf1cadE312776e476E6A58704F39Fcb070c',
  maxMintAmount: 2,
  presaleMaxMintAmount: 4,
  price: 0.00
}

export { config }
