

const Header = () => {
    return (
        <div className="button">
         
                  <a className="" href="http://ghostlers.io/" target="_blank" rel="noreferrer">
                      
                      <img className="button--img1" src="https://media.discordapp.net/attachments/1034132708760244365/1047891637189230812/Ghostler_Logo_Melted-03.png" alt={"Home"} />
            </a>
            </div>
       
  );
};

export default Header;
